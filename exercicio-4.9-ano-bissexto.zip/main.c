#include <stdio.h>

int main()
{
    int ano, prox_bissexto;
    
    printf("Digite um valor que represente um ano: ");
    scanf("%d", &ano);
    
    if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0)
        printf("O ano informado é bissexto.");
        
    else
    {
        prox_bissexto = ano + (4 - (ano % 4));
        printf("O próximo ano bissexto é: %d", prox_bissexto);
    }
    
    
    
    return 0;
}
