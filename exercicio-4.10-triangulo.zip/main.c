#include <stdio.h>

int main()
{
    float x, y, z;
    
    printf("Digite o valor de um lado do triângulo: ");
    scanf("%f", &x);
    
    printf("Digite o valor de outro lado do triângulo: ");
    scanf("%f", &y);
    
    printf("Digite o valor do último lado do triângulo: ");
    scanf("%f", &z);

    if( x + y > z && x + z > y && y + z > x)
    {
        if (x == y && x == z)
            printf("O triangulo é equilátero.");
    
        if ((x == y && x != z) || x != y && x == z) 
            printf("O triangulo é isóceles.");
    
        if (x != y && x != z)
            printf("O triangulo é escaleno."); 
    }
    
    else
        printf("Os valores informados não formam um triângulo.");

    return 0;
}
