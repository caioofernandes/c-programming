#include <stdio.h>

int main()
{
    char op;
    float a, b;
    
    printf("Informe uma operação aritmética dentre as apresentadas --> ('+'; '-'; '/'; '*'): ");
    scanf("%c", &op);
    
    if( op != '+' && op != '-' && op != '*' && op != '/')
    {
        printf("Operador inválido.");
        return 0;
    }
        
    
    printf("Informe um valor para o primeiro valor da operação: ");
    scanf("%f", &a);

    printf("Informe um valor para o segundo valor da operação: ");
    scanf("%f", &b);
    
    if( op == '/' && b == 0)
        printf("O valor de b deve ser diferente de 0.");
    
    else 
    {
        switch(op)
        {
            case '+': printf("a + b = %.2f", a + b);
            break;
        
            case '-': printf("a - b = %.2f", a - b);
            break;
        
            case '*': printf("a * b = %.2f", a * b);
            break;
        
            case '/': printf("a / b = %.2f", a / b);
            break;
            
        }
    }
    
    return 0;
}
