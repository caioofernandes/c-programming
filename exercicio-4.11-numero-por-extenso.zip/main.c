#include <stdio.h>

int main()
{
    int numero;
    
    printf("Digite um número inteiro de 1 a 5: ");
    scanf("%d", &numero);
    
    switch(numero) 
{
    
    case 1 : printf("UM");
    break;

    case 2 : printf("DOIS");
    break;

    case 3 : printf("TRÊS");
    break;
    
    case 4 : printf("QUATRO");
    break;
    
    case 5 : printf("CINCO");
    break;

    default: printf("O número informado não está no intervalo de 1 e 5.");
    break;
}

    return 0;
}

